/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gross_salary;

/**
 *
 * @author nmsaf
 */
public class company {
    
    public static void main(String[] args){
        
        //create instance for employees
        
        manager man = new manager ("M0001", "Malinga", 80000);
        clerk cle = new clerk ("C0010", "Amjath", 30000, "grade 1");
        employee otherEmployee = new employee("E0013", "Sivanjali", 20000);
        
        //calculate and display the gross salary
        
        System.out.println("Manager:");
        System.out.println("Employee No:" + man.getEmployeeNo());
        System.out.println("Employee Name:" + man.getEmployeeName());
        System.out.println("Basic Salary:" + man.getBasicSalary());
        System.out.println("Gross Salary:" + man.calGrossSalary());
        System.out.println();
        
        System.out.println("\nClerk:");
        System.out.println("Employee No: " + cle.getEmployeeNo());
        System.out.println("Employee Name: " + cle.getEmployeeName());
        System.out.println("Basic Salary: " + cle.getBasicSalary());
        System.out.println("Category: " + cle.getCategory());
        System.out.println("Gross Salary: " + cle.calGrossSalary());

        System.out.println("\nOther Employee:");
        System.out.println("Employee No: " + otherEmployee.getEmployeeNo());
        System.out.println("Employee Name: " + otherEmployee.getEmployeeName());
        System.out.println("Basic Salary: " + otherEmployee.getBasicSalary());
        System.out.println("Gross Salary: " + otherEmployee.calGrossSalary());
    }
}
