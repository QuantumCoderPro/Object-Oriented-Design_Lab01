/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gross_salary;

/**
 *
 * @author nmsaf
 */
public class employee {

    private String employeeNo;
    private String employeeName;
    private double basicSalary;
    
    /**
     * @return the employeeNo
     */
    public String getEmployeeNo() {
        return employeeNo;
    }

    /**
     * @param employeeNo the employeeNo to set
     */
    public void setEmployeeNo(String employeeNo) {
        this.employeeNo = employeeNo;
    }

    /**
     * @return the employeeName
     */
    public String getEmployeeName() {
        return employeeName;
    }

    /**
     * @param employeeName the employeeName to set
     */
    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    /**
     * @return the basicSalary
     */
    public double getBasicSalary() {
        return basicSalary;
    }

    /**
     * @param basicSalary the basicSalary to set
     */
    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }
    
    public employee(String employeeNo, String employeeName, double basicSalary){
        this.employeeNo = employeeNo;
        this.employeeName = employeeName;
        this.basicSalary = basicSalary;
    }
    
    public double calBonus(){
        return 0.05 * basicSalary;
    }
    public double calGrossSalary(){
        return basicSalary + calBonus();
    }
}
