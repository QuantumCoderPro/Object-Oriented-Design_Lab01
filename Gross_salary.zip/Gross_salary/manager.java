/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gross_salary;

/**
 *
 * @author nmsaf
 */
public class manager extends employee{
    public manager(String employeeNo, String employeeName, double basicSalary){
        super(employeeNo, employeeName, basicSalary);
    }
    
    // override
    
@Override
            public double calBonus(){
        return 0.2 * getBasicSalary();
    }
    public double calTax(){
        return 0.15 * getBasicSalary();
    }
    
    @Override
    public double calGrossSalary(){
        return getBasicSalary() + calBonus() - calTax();
    }
    
}
