/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gross_salary;

/**
 *
 * @author nmsaf
 */
public class clerk extends employee{

    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }
    private String category;
    
    public clerk(String employeeNo, String employeeName, double basicSalary, String category){
        super(employeeNo, employeeName, basicSalary);
        this.category = category;
    }
    // override
    
    @Override
    public double calBonus(){
        return 0.1 * getBasicSalary();
    }
    
    @Override
    public double calGrossSalary(){
        return getBasicSalary() + calBonus();
    }
    
}
